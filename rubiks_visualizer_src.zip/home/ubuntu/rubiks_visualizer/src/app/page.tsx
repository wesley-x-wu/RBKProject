import CubeVisualizer from "@/components/CubeVisualizer/CubeVisualizer";
import Chatbot from "@/components/Chatbot/Chatbot"; // Import the Chatbot component
import React, { useState, useCallback } from "react";

export default function HomePage() {
  const [moveToExecute, setMoveToExecute] = useState<string | null>(null);
  const [algorithmToExecute, setAlgorithmToExecute] = useState<string | null>(
    null
  );
  const [resetCubeSignal, setResetCubeSignal] = useState<boolean>(false);
  const [currentCubeState, setCurrentCubeState] = useState<any>(null); // Placeholder for actual cube state

  const handleSingleMove = useCallback((move: string) => {
    console.log(`Performing single move: ${move}`);
    setMoveToExecute(move);
    setTimeout(() => setMoveToExecute(null), 100);
  }, []);

  const handleAlgorithm = useCallback(() => {
    const algoInput = document.getElementById(
      "algorithmInput"
    ) as HTMLInputElement;
    if (algoInput && algoInput.value) {
      console.log(`Executing algorithm: ${algoInput.value}`);
      setAlgorithmToExecute(algoInput.value);
      setTimeout(() => setAlgorithmToExecute(null), 100);
    }
  }, []);

  const handleResetCube = useCallback(() => {
    console.log("Resetting cube signal sent");
    setResetCubeSignal(true);
    setTimeout(() => setResetCubeSignal(false), 100);
  }, []);

  // This function would be called by CubeVisualizer whenever the state changes
  const handleCubeStateChange = (newState: any) => {
    setCurrentCubeState(newState);
  };

  const handleChatbotSuggestedMove = (move: string) => {
    // This function will allow the chatbot to trigger moves on the cube
    // For now, just log it. It could setMoveToExecute or setAlgorithmToExecute
    console.log(`Chatbot suggested move: ${move}`);
    setAlgorithmToExecute(move); // Assuming suggestions are algorithms for now
    setTimeout(() => setAlgorithmToExecute(null), 100);
  };

  const basicMoves = [
    "U", "U'", "D", "D'", "L", "L'", "R", "R'", "F", "F'", "B", "B'",
    "M", "M'", "x", "y", "z",
  ];
  const doubleMoves = basicMoves
    .filter((m) => !["M", "E", "S", "x", "y", "z"].includes(m))
    .map((m) => m + "2");
  const allMoves = [...basicMoves, ...doubleMoves].sort();

  return (
    <main className="flex min-h-screen flex-col items-center justify-start p-8 bg-gray-100 pt-16">
      <h1 className="text-5xl font-bold mb-10 text-gray-800">
        Rubik's Cube Visualizer
      </h1>
      <div
        style={{
          width: "100%",
          maxWidth: "600px",
          marginBottom: "2rem",
          boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
          borderRadius: "8px",
          overflow: "hidden",
        }}
      >
        <CubeVisualizer
          executeMove={moveToExecute || algorithmToExecute}
          resetCubeSignal={resetCubeSignal}
          // onStateChange={handleCubeStateChange} // Prop to be added to CubeVisualizer
        />
      </div>
      <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 mb-4 w-full max-w-xl">
        {allMoves.map((move) => (
          <button
            key={move}
            onClick={() => handleSingleMove(move)}
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition-colors duration-150 text-sm sm:text-base"
          >
            {move}
          </button>
        ))}
      </div>
      <div className="w-full max-w-xl mt-4">
        <label
          htmlFor="algorithmInput"
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          Algorithm / Scramble:
        </label>
        <input
          type="text"
          id="algorithmInput"
          placeholder="Enter moves (e.g., R U R' U')"
          className="w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
        />
        <div className="flex space-x-2 mt-2">
          <button
            onClick={handleAlgorithm}
            className="flex-1 bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded transition-colors duration-150"
          >
            Execute Algorithm
          </button>
          <button
            onClick={handleResetCube}
            className="flex-1 bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded transition-colors duration-150"
          >
            Reset Cube
          </button>
        </div>
      </div>
      
      {/* Chatbot Integration */}
      <Chatbot cubeState={currentCubeState} onSuggestedMove={handleChatbotSuggestedMove} />

    </main>
  );
}

