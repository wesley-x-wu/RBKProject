import React, { useState, useEffect, useCallback, useRef } from "react";
import type { SimpleCubeState } from "../CubeVisualizer/CubeVisualizer"; // Assuming type is exported

interface Message {
  id: string;
  text: string;
  sender: "user" | "bot";
  suggestions?: string[];
  isThinking?: boolean;
}

interface ChatbotProps {
  cubeState?: SimpleCubeState | null;
  onSuggestedMove?: (move: string) => void;
  onAlgorithmRequest?: (algorithmName: string) => void; // For bot to request visualizer to show an alg
}

const Chatbot: React.FC<ChatbotProps> = ({ cubeState, onSuggestedMove, onAlgorithmRequest }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isOpen, setIsOpen] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  // Initial greeting message
  useEffect(() => {
    setMessages([
      {
        id: Date.now().toString(),
        text: "Hello! I am your CFOP Assistant. How can I help you solve the Rubik's Cube?",
        sender: "bot",
        suggestions: ["What is CFOP?", "Explain Cross", "Analyze my cube"],
      },
    ]);
  }, []);

  const addBotMessage = (text: string, suggestions?: string[]) => {
    setMessages((prev) => [
      ...prev.filter(m => !m.isThinking),
      {
        id: (Date.now() + Math.random()).toString(), // Ensure unique ID
        text,
        sender: "bot",
        suggestions,
      },
    ]);
  };
  
  const addThinkingMessage = () => {
    setMessages(prev => [...prev, { id: "thinking", text: "Thinking...", sender: "bot", isThinking: true}]);
  }

  // CFOP Phase Analysis (Simplified for now)
  const analyzeCubeStateForCFOP = useCallback(() => {
    addThinkingMessage();
    setTimeout(() => {
        if (!cubeState || !cubeState.stickers) {
            addBotMessage("I don't have the current cube state. Please make a move or reset the cube.", ["What is Cross?", "Explain F2L"]);
            return;
        }

        // Placeholder: In a real scenario, this would involve complex logic.
        // For now, we'll just acknowledge the state and give generic advice.
        let analysis = "Cube state received. Let's see...";
        let suggestions: string[] = ["Tips for Cross", "Show F2L cases"];

        // Extremely simplified Cross check (assuming U face is White)
        const uFace = cubeState.stickers["U"];
        const fFace = cubeState.stickers["F"]; // Need center piece color
        // This is a very basic check and not robust
        if (uFace && uFace.every(s => s === 'W')) {
            analysis += " It looks like your U face (White) is solved! That's a good start for OLL/PLL if F2L is done.";
            suggestions = ["Explain OLL", "Explain PLL", "Common OLL algorithms"];
        } else {
            analysis += " I can help you with any CFOP step. What are you working on?";
        }
        // This is where actual phase detection would go.
        // e.g. isCrossSolved(), getF2LPairsStatus(), getOLLCase(), getPLLCase()
        addBotMessage(analysis, suggestions);
    }, 1000);
  }, [cubeState]);

  const getCFOPInfo = (topic: string) => {
    addThinkingMessage();
    setTimeout(() => {
        let response = "";
        let suggestions: string[] = ["What is CFOP?", "Explain Cross", "Explain F2L", "Explain OLL", "Explain PLL"];

        switch (topic.toLowerCase()) {
            case "cfop":
                response = "CFOP (Cross, F2L, OLL, PLL) is a popular 3x3 speedsolving method. It involves solving the cube layer by layer, but with optimized steps. Cross: forms a cross on one face. F2L: solves the first two layers simultaneously. OLL: orients all last layer pieces. PLL: permutes all last layer pieces.";
                break;
            case "cross":
                response = "The Cross is the first step. Goal: Solve 4 edge pieces on one face (e.g., white edges on the white face) matching them with the side center pieces. It's usually solved intuitively and should take 8 moves or fewer. Many solvers do it on the bottom face to improve lookahead for F2L.";
                suggestions = ["Cross tips", "Color neutrality for Cross"];
                break;
            case "f2l":
                response = "F2L (First Two Layers) is the second step. Goal: Solve the 4 corner-edge pairs of the first two layers simultaneously. There are 41 basic cases, but many solve it intuitively. This is often the longest but most rewarding part of the solve to master.";
                suggestions = ["F2L case example", "How to practice F2L?"];
                break;
            case "oll":
                response = "OLL (Orient Last Layer) is the third step. Goal: Orient all pieces of the last layer so the entire face shows the correct color (e.g., all yellow on top). There are 57 algorithms for full OLL. Many start with 2-Look OLL (10 algorithms total: 3 for edge orientation, 7 for corner orientation).";
                suggestions = ["What is 2-Look OLL?", "Show an OLL algorithm"];
                break;
            case "pll":
                response = "PLL (Permute Last Layer) is the final step. Goal: Permute (rearrange) the already oriented last layer pieces to their final solved positions. There are 21 algorithms for full PLL. 2-Look PLL is also an option for beginners (corners first, then edges).";
                suggestions = ["What is 2-Look PLL?", "Show a PLL algorithm"];
                break;
            default:
                response = `I can provide information on CFOP, Cross, F2L, OLL, or PLL. What would you like to know?`;
                break;
        }
        addBotMessage(response, suggestions);
    }, 700);
  };

  const handleSendMessage = useCallback(() => {
    if (inputValue.trim() === "") return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      sender: "user",
    };
    setMessages((prev) => [...prev, userMessage]);
    const lowerInput = inputValue.toLowerCase();

    if (lowerInput.includes("analyze") || lowerInput.includes("check my cube")) {
      analyzeCubeStateForCFOP();
    } else if (lowerInput.startsWith("what is ") || lowerInput.startsWith("explain ")) {
      const topic = lowerInput.replace("what is ", "").replace("explain ", "").trim();
      getCFOPInfo(topic);
    } else if (lowerInput.includes("cfop")) {
        getCFOPInfo("cfop");
    } else if (lowerInput.includes("cross")) {
        getCFOPInfo("cross");
    } else if (lowerInput.includes("f2l")) {
        getCFOPInfo("f2l");
    } else if (lowerInput.includes("oll")) {
        getCFOPInfo("oll");
    } else if (lowerInput.includes("pll")) {
        getCFOPInfo("pll");
    } else {
      addThinkingMessage();
      setTimeout(() => {
        addBotMessage("I'm not sure how to respond to that yet. Try asking about a CFOP step or to analyze the cube.", ["Explain CFOP", "Analyze my cube"]);
      }, 500);
    }
    setInputValue("");
  }, [inputValue, analyzeCubeStateForCFOP]);

  const handleSuggestionClick = (suggestion: string) => {
    // Simulate user typing the suggestion and sending it
    const userMessage: Message = {
      id: Date.now().toString(),
      text: suggestion,
      sender: "user",
    };
    setMessages((prev) => [...prev, userMessage]);
    const lowerSuggestion = suggestion.toLowerCase();

    if (lowerSuggestion.includes("analyze")) {
        analyzeCubeStateForCFOP();
    } else if (lowerSuggestion.startsWith("what is ") || lowerSuggestion.startsWith("explain ")) {
        const topic = lowerSuggestion.replace("what is ", "").replace("explain ", "").trim();
        getCFOPInfo(topic);
    } else if (onSuggestedMove && (suggestion.match(/[RUFLDBMESxyz]['2w]?/g))) { // Basic check if it's a move/alg
        onSuggestedMove(suggestion);
        addBotMessage(`Okay, applying: ${suggestion}`);
    } else {
        // Fallback for other suggestions, or let handleSendMessage logic take over if it were more complex
        getCFOPInfo(lowerSuggestion); // Try to get info based on suggestion text
    }
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 bg-blue-600 text-white p-3 rounded-full shadow-lg hover:bg-blue-700 transition-colors z-50"
      >
        Chat
      </button>
    );
  }

  return (
    <div className="fixed bottom-0 right-0 mb-4 mr-4 w-full max-w-md bg-white rounded-lg shadow-xl border border-gray-300 z-50 flex flex-col" style={{ height: "550px" }}>
      <div className="bg-blue-600 text-white p-3 flex justify-between items-center rounded-t-lg">
        <h3 className="font-semibold">CFOP Assistant</h3>
        <button onClick={() => setIsOpen(false)} className="text-white hover:text-gray-200 text-2xl leading-none">&times;</button>
      </div>
      <div className="flex-grow p-4 overflow-y-auto space-y-3 bg-gray-50">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex mb-2 ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-xs md:max-w-sm lg:max-w-md px-4 py-2 rounded-xl shadow ${ 
                msg.sender === "user"
                  ? "bg-blue-500 text-white rounded-br-none"
                  : "bg-gray-200 text-gray-800 rounded-bl-none"
              }`}
            >
              <p className="text-sm whitespace-pre-wrap">{msg.isThinking ? <span className="italic">Thinking...</span> : msg.text}</p>
              {msg.sender === "bot" && !msg.isThinking && msg.suggestions && (
                <div className="mt-2 flex flex-wrap gap-1">
                  {msg.suggestions.map((s, index) => (
                    <button
                      key={index}
                      onClick={() => handleSuggestionClick(s)}
                      className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full hover:bg-blue-200 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-400"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      <div className="p-3 border-t border-gray-200 bg-white rounded-b-lg">
        <div className="flex space-x-2">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            placeholder="Ask about CFOP or analyze..."
            className="flex-grow p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
          />
          <button
            onClick={handleSendMessage}
            className="bg-blue-500 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-blue-400"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
};

export default Chatbot;

