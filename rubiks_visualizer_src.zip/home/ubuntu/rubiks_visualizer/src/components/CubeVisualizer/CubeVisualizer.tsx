import React, { useRef, useEffect, useState, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

const stickerOffset = 0.001;
const pieceSize = 1;
const gap = 0.05;
const animationDuration = 300; 

const colors: { [key: string]: { name: string, hex: number } } = {
  F: { name: 'Green', hex: 0x009b48 },
  B: { name: 'Blue', hex: 0x0045ad },
  U: { name: 'White', hex: 0xffffff },
  D: { name: 'Yellow', hex: 0xffd500 },
  R: { name: 'Red', hex: 0xb71234 },
  L: { name: 'Orange', hex: 0xff5800 }
};

const faceOrder = ['U', 'L', 'F', 'R', 'B', 'D'];
const stickerIndicesOrder = [
    [-1,1,1], [0,1,1], [1,1,1], // U face, front row (relative to U face)
    [-1,1,0], [0,1,0], [1,1,0], // U face, middle row
    [-1,1,-1],[0,1,-1],[1,1,-1],// U face, back row
    // ... and so on for L, F, R, B, D faces
]; // This needs to be carefully defined for each face

interface Cubie extends THREE.Group {
  userData: {
    initialX: number;
    initialY: number;
    initialZ: number;
    currentX: number;
    currentY: number;
    currentZ: number;
    id: string;
    stickers: { face: string, color: string }[]; // e.g. [{face: 'U', color: 'White'}, {face: 'F', color: 'Green'}]
  };
}

export interface SimpleCubeState {
    // Example: { U1: 'W', U2: 'W', ..., D9: 'Y' }
    // Or a more structured representation: { U: ['W', 'W', ...], L: [...], ... }
    stickers: { [face: string]: string[] }; // e.g. U: ['W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W']
    // Could also include cubie positions and orientations if needed for advanced logic
    lastMove?: string;
}

function getStickerColorName(hexColor: number): string {
    for (const key in colors) {
        if (colors[key].hex === hexColor) return colors[key].name.charAt(0); // Return 'W' for White, etc.
    }
    return '?';
}

function createSticker(faceKey: keyof typeof colors, size: number): THREE.Mesh {
  const stickerGeometry = new THREE.PlaneGeometry(size - gap * 2, size - gap * 2);
  const stickerMaterial = new THREE.MeshBasicMaterial({ color: colors[faceKey].hex, side: THREE.DoubleSide });
  const stickerMesh = new THREE.Mesh(stickerGeometry, stickerMaterial);
  stickerMesh.userData.face = faceKey; // Store which face this sticker belongs to on the cubie
  stickerMesh.userData.colorName = colors[faceKey].name.charAt(0);
  return stickerMesh;
}

function createCubie(x: number, y: number, z: number): Cubie {
  const cubie = new THREE.Group() as Cubie;
  const coreGeometry = new THREE.BoxGeometry(pieceSize, pieceSize, pieceSize);
  const coreMaterial = new THREE.MeshBasicMaterial({ color: 0x1a1a1a });
  const core = new THREE.Mesh(coreGeometry, coreMaterial);
  cubie.add(core);

  cubie.userData = { 
    initialX: x, initialY: y, initialZ: z, 
    currentX: x, currentY: y, currentZ: z, 
    id: `cubie_${x}_${y}_${z}`,
    stickers: []
  };

  const stickerSize = pieceSize - gap;

  if (z === 1) { 
    const sticker = createSticker('F', stickerSize);
    sticker.position.z = pieceSize / 2 + stickerOffset;
    cubie.add(sticker);
    cubie.userData.stickers.push({face: 'F', color: 'Green'});
  }
  if (z === -1) { 
    const sticker = createSticker('B', stickerSize);
    sticker.position.z = -pieceSize / 2 - stickerOffset;
    sticker.rotation.y = Math.PI;
    cubie.add(sticker);
    cubie.userData.stickers.push({face: 'B', color: 'Blue'});
  }
  if (y === 1) { 
    const sticker = createSticker('U', stickerSize);
    sticker.position.y = pieceSize / 2 + stickerOffset;
    sticker.rotation.x = -Math.PI / 2;
    cubie.add(sticker);
    cubie.userData.stickers.push({face: 'U', color: 'White'});
  }
  if (y === -1) { 
    const sticker = createSticker('D', stickerSize);
    sticker.position.y = -pieceSize / 2 - stickerOffset;
    sticker.rotation.x = Math.PI / 2;
    cubie.add(sticker);
    cubie.userData.stickers.push({face: 'D', color: 'Yellow'});
  }
  if (x === 1) { 
    const sticker = createSticker('R', stickerSize);
    sticker.position.x = pieceSize / 2 + stickerOffset;
    sticker.rotation.y = Math.PI / 2;
    cubie.add(sticker);
    cubie.userData.stickers.push({face: 'R', color: 'Red'});
  }
  if (x === -1) { 
    const sticker = createSticker('L', stickerSize);
    sticker.position.x = -pieceSize / 2 - stickerOffset;
    sticker.rotation.y = -Math.PI / 2;
    cubie.add(sticker);
    cubie.userData.stickers.push({face: 'L', color: 'Orange'});
  }

  cubie.position.set(x * (pieceSize + gap), y * (pieceSize + gap), z * (pieceSize + gap));
  return cubie;
}

interface CubeVisualizerProps {
  onMoveComplete?: () => void; 
  executeMove?: string | null; 
  onAlgorithmComplete?: () => void;
  resetCubeSignal?: boolean;
  onStateChange?: (newState: SimpleCubeState) => void;
}

const CubeVisualizer: React.FC<CubeVisualizerProps> = ({ executeMove, onMoveComplete, onAlgorithmComplete, resetCubeSignal, onStateChange }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const rubiksCubeRef = useRef<THREE.Group | null>(null);
  const cubiesRef = useRef<Cubie[]>([]);
  const [isAnimating, setIsAnimating] = useState(false);

  const actualPieceSize = pieceSize + gap;

  const emitCubeState = useCallback((lastMovePerformed?: string) => {
    if (!onStateChange || cubiesRef.current.length === 0 || !sceneRef.current) return;

    const state: SimpleCubeState = { stickers: {}, lastMove: lastMovePerformed };
    faceOrder.forEach(face => state.stickers[face] = Array(9).fill('?'));

    // This is a complex part: determining which sticker is where on each face.
    // For each of the 6 faces of the cube, we need to identify the 9 stickers.
    // This requires raycasting from 9 points on each face or transforming cubie sticker normals.
    // For a simplified initial version, we can try to map based on cubie currentX,Y,Z and their initial sticker faces.
    // This is a placeholder for the actual complex logic.
    
    // Simplified placeholder logic (not accurate for rotated pieces within a layer during a move)
    // A full implementation would raycast or use matrix transformations to find visible sticker colors.
    cubiesRef.current.forEach(cubie => {
        // This logic is NOT complete or accurate for phase detection.
        // It just shows an attempt to get some data out.
        // True state detection needs to know which *original* sticker of a cubie is now facing outwards on U1, U2 etc.
        // For example, a corner piece has 3 stickers. When it moves, we need to know which of those 3 is on the U face, F face etc.
    });

    // For now, let's send a very dummy state
    faceOrder.forEach(faceKey => {
        const faceColorChar = colors[faceKey].name.charAt(0);
        state.stickers[faceKey] = Array(9).fill(faceColorChar); // Shows solved state
    });
    // Example: if U face center is cubiesRef.current.find(c => c.userData.currentX === 0 && c.userData.currentY === 1 && c.userData.currentZ === 0)
    // then find its sticker that has normal vector (0,1,0) in world space.

    console.log("Emitting simplified cube state (placeholder)", state);
    onStateChange(state);
  }, [onStateChange]);


  const resetCube = useCallback(() => {
    if (!rubiksCubeRef.current || cubiesRef.current.length === 0) return;
    setIsAnimating(true);
    cubiesRef.current.forEach(cubie => {
      const { initialX, initialY, initialZ } = cubie.userData;
      cubie.position.set(initialX * actualPieceSize, initialY * actualPieceSize, initialZ * actualPieceSize);
      cubie.rotation.set(0, 0, 0); 
      cubie.userData.currentX = initialX;
      cubie.userData.currentY = initialY;
      cubie.userData.currentZ = initialZ;
    });
    rubiksCubeRef.current.rotation.set(0,0,0);
    if(controlsRef.current) controlsRef.current.reset();
    setIsAnimating(false);
    emitCubeState("RESET");
    console.log("Cube reset");
  }, [actualPieceSize, emitCubeState]);

  useEffect(() => {
    if (resetCubeSignal) {
      resetCube();
    }
  }, [resetCubeSignal, resetCube]);

  useEffect(() => {
    if (!mountRef.current || rendererRef.current) return;
    const currentMount = mountRef.current;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xeeeeee);
    sceneRef.current = scene;
    const camera = new THREE.PerspectiveCamera(50, currentMount.clientWidth / currentMount.clientHeight, 0.1, 1000);
    camera.position.set(actualPieceSize * 2.5, actualPieceSize * 2.5, actualPieceSize * 3.5);
    cameraRef.current = camera;
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(currentMount.clientWidth, currentMount.clientHeight);
    rendererRef.current = renderer;
    currentMount.appendChild(renderer.domElement);
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true; controls.dampingFactor = 0.05;
    controls.minDistance = actualPieceSize * 2; controls.maxDistance = actualPieceSize * 10;
    controlsRef.current = controls;
    const rubiksCube = new THREE.Group();
    rubiksCubeRef.current = rubiksCube;
    const tempCubies: Cubie[] = [];
    for (let x = -1; x <= 1; x++) {
      for (let y = -1; y <= 1; y++) {
        for (let z = -1; z <= 1; z++) {
          const cubie = createCubie(x, y, z);
          tempCubies.push(cubie);
          rubiksCube.add(cubie);
        }
      }
    }
    cubiesRef.current = tempCubies;
    scene.add(rubiksCube);
    emitCubeState("INIT");
    const animate = () => { requestAnimationFrame(animate); controls.update(); renderer.render(scene, camera); };
    animate();
    const handleResize = () => {
      if (currentMount && cameraRef.current && rendererRef.current) {
        cameraRef.current.aspect = currentMount.clientWidth / currentMount.clientHeight;
        cameraRef.current.updateProjectionMatrix();
        rendererRef.current.setSize(currentMount.clientWidth, currentMount.clientHeight);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
      if (currentMount && rendererRef.current?.domElement) {
        if (currentMount.contains(rendererRef.current.domElement)) {
            currentMount.removeChild(rendererRef.current.domElement);
        }
      }
      controlsRef.current?.dispose(); rendererRef.current?.dispose();
      sceneRef.current?.traverse(object => {
        if (object instanceof THREE.Mesh) {
          object.geometry?.dispose();
          const material = object.material as THREE.Material | THREE.Material[];
          if (Array.isArray(material)) material.forEach(mat => mat.dispose());
          else material?.dispose();
        }
      });
      rendererRef.current = null;
    };
  }, [actualPieceSize, emitCubeState]);

  const performMove = useCallback(async (move: string) => {
    if (isAnimating || !rubiksCubeRef.current) return;
    setIsAnimating(true);
    const axis = new THREE.Vector3();
    let layerSelector: (cubie: Cubie) => boolean;
    let angle = Math.PI / 2;
    const prime = move.includes("'");
    const double = move.includes("2");
    const baseMove = move.replace(/['2w]/g, ""); // Remove w for wide moves for now
    const isWide = move.includes("w"); // TODO: Implement wide move logic for layerSelector

    if (prime) angle = -Math.PI / 2;
    if (double) angle = Math.PI;

    let wholeCubeRotation = false;

    switch (baseMove) {
      case 'U': layerSelector = c => c.userData.currentY === 1; axis.set(0, 1, 0); angle *= -1; break;
      case 'D': layerSelector = c => c.userData.currentY === -1; axis.set(0, 1, 0); break;
      case 'L': layerSelector = c => c.userData.currentX === -1; axis.set(1, 0, 0); break;
      case 'R': layerSelector = c => c.userData.currentX === 1; axis.set(1, 0, 0); angle *= -1; break;
      case 'F': layerSelector = c => c.userData.currentZ === 1; axis.set(0, 0, 1); angle *= -1; break;
      case 'B': layerSelector = c => c.userData.currentZ === -1; axis.set(0, 0, 1); break;
      case 'M': layerSelector = c => c.userData.currentX === 0; axis.set(1,0,0); break; // M slice
      case 'E': layerSelector = c => c.userData.currentY === 0; axis.set(0,1,0); break; // E slice
      case 'S': layerSelector = c => c.userData.currentZ === 0; axis.set(0,0,1); angle *= -1; break; // S slice
      case 'x': layerSelector = _c => true; axis.set(1,0,0); angle *= -1; wholeCubeRotation = true; break;
      case 'y': layerSelector = _c => true; axis.set(0,1,0); angle *= -1; wholeCubeRotation = true; break;
      case 'z': layerSelector = _c => true; axis.set(0,0,1); angle *= -1; wholeCubeRotation = true; break;
      default: console.warn("Unknown move:", move); setIsAnimating(false); return;
    }

    const pivot = new THREE.Object3D();
    pivot.rotation.set(0,0,0);
    sceneRef.current?.add(pivot); // Add to scene to establish world context
    // If it's a whole cube rotation, the pivot should be at the world origin.
    // If it's a layer turn, pivot is also at world origin because cubies are positioned relative to it.

    const selectedCubies = wholeCubeRotation ? [rubiksCubeRef.current] : cubiesRef.current.filter(layerSelector);
    
    selectedCubies.forEach(obj => {
        if(obj) sceneRef.current?.attach(obj); // Attach to scene from current parent
    });
    selectedCubies.forEach(obj => {
        if(obj) pivot.attach(obj); // Then attach to pivot
    });

    const start = Date.now();
    const animateRotation = () => {
      const now = Date.now();
      const t = Math.min((now - start) / animationDuration, 1);
      pivot.rotation.setFromVector3(axis.clone().multiplyScalar(angle * t));
      if (t < 1) {
        requestAnimationFrame(animateRotation);
      } else {
        pivot.rotation.setFromVector3(axis.clone().multiplyScalar(angle));
        pivot.updateMatrixWorld(true);

        selectedCubies.forEach(obj => {
            if (!obj) return;
            sceneRef.current?.attach(obj); // Detach from pivot, reattach to scene (or main cube group if not whole rotation)
            obj.applyMatrix4(pivot.matrixWorld); // Apply pivot's world transformation
            obj.updateMatrixWorld(true);

            if (!wholeCubeRotation && obj instanceof THREE.Group) { // Update logical positions for individual cubies
                const cubie = obj as Cubie;
                const tempVec = new THREE.Vector3();
                // Get position relative to the rubiksCubeRef.current if it's the parent
                // For simplicity, we assume positions are world for a moment, then map back
                // This needs to be accurate: position in the context of the Rubik's Cube group
                const worldPos = new THREE.Vector3();
                cubie.getWorldPosition(worldPos);
                const cubeRelativePos = rubiksCubeRef.current!.worldToLocal(worldPos.clone());

                cubie.userData.currentX = Math.round(cubeRelativePos.x / actualPieceSize);
                cubie.userData.currentY = Math.round(cubeRelativePos.y / actualPieceSize);
                cubie.userData.currentZ = Math.round(cubeRelativePos.z / actualPieceSize);
            }
        });
        sceneRef.current?.remove(pivot);
        setIsAnimating(false);
        emitCubeState(move);
        if (onMoveComplete) onMoveComplete();
      }
    };
    animateRotation();
  }, [isAnimating, onMoveComplete, actualPieceSize, emitCubeState]);

  useEffect(() => {
    if (executeMove && !isAnimating) {
      const moves = executeMove.trim().split(/\s+/);
      let currentMoveIndex = 0;
      const executeNextMove = async () => {
        if (currentMoveIndex < moves.length) {
          const move = moves[currentMoveIndex];
          if (move) {
            await performMove(move);
            currentMoveIndex++;
            setTimeout(executeNextMove, animationDuration + 50); // Wait for animation + buffer
          } else {
            currentMoveIndex++;
            executeNextMove();
          }
        } else {
          if (onAlgorithmComplete) onAlgorithmComplete();
        }
      };
      executeNextMove();
    }
  }, [executeMove, isAnimating, performMove, onAlgorithmComplete]);

  return <div ref={mountRef} style={{ width: '100%', height: '500px', touchAction: 'none' }} />;
};

export default CubeVisualizer;

